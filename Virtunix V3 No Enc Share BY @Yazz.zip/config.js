module.exports = {
  BOT_TOKEN: "Token",
  OWNER_ID: ["6484803509"],
};