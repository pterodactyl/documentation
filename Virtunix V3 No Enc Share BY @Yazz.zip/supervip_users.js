const supervipUsers = [

  { id: '6484803509', expiry: 1684022400000 }, 
  
];

module.exports = supervipUsers;
